package com.biblioteca.factory;

public class LibroDigital implements Libro {
    private final String titulo;
    private final String autor;
    private final double tamanioMB; //Atributo que se usa para diferenciarlo de un libro comun

    public LibroDigital(String titulo, String autor, double tamanioMB) {
        this.titulo = titulo;
        this.autor = autor;
        this.tamanioMB = tamanioMB;
    }

    @Override
    public String getTitulo() { return titulo; }

    @Override
    public String getAutor() { return autor; }

    public double getTamanioMB() { return tamanioMB; }

    @Override
    public String getTipo() { return "Digital"; }

    @Override
    public Libro clone() {
        return new LibroDigital(this.titulo, this.autor, this.tamanioMB);
    }

    @Override
    public String toString() {
        return "LibroDigital{titulo='" + titulo + "', autor='" + autor + "', tamanioMB=" + tamanioMB + "}";
    }
}
