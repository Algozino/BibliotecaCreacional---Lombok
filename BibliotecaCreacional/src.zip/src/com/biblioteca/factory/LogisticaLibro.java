package com.biblioteca.factory;

public class LogisticaLibro {
    public static Libro crearLibro(String tipo, String titulo, String autor, double extra) {
        if (tipo == null) throw new IllegalArgumentException("Tipo no puede ser null");
        switch (tipo.toLowerCase()) {
            case "fisico":
            case "físico":
                return new LibroFisico(titulo, autor, extra); // extra = pesoKg
            case "digital":
                return new LibroDigital(titulo, autor, extra); // extra = tamanioMB
            default:
                throw new IllegalArgumentException("Tipo de libro desconocido: " + tipo);
        }
    }
}
