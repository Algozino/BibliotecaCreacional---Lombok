package com.biblioteca.factory;

public class LibroFisico implements Libro {
    private final String titulo;
    private final String autor;
    private final double pesoKg; //Atributo que se usa para diferenciarlo de un libro comun

    public LibroFisico(String titulo, String autor, double pesoKg) {
        this.titulo = titulo;
        this.autor = autor;
        this.pesoKg = pesoKg;
    }

    @Override
    public String getTitulo() { return titulo; }

    @Override
    public String getAutor() { return autor; }

    public double getPesoKg() { return pesoKg; }

    @Override
    public String getTipo() { return "Fisico"; }

    @Override
    public Libro clone() {
        return new LibroFisico(this.titulo, this.autor, this.pesoKg);
    }

    @Override
    public String toString() {
        return "LibroFisico{titulo='" + titulo + "', autor='" + autor + "', pesoKg=" + pesoKg + "}";
    }
}
