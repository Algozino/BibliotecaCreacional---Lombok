package com.biblioteca.builder;

import java.time.LocalDate;

public class Usuario implements Cloneable {
    private final String nombre;
    private final String email;
    private final String direccion;
    private final String telefono;
    private final LocalDate fechaNacimiento;

    private Usuario(Builder b) {
        this.nombre = b.nombre;
        this.email = b.email;
        this.direccion = b.direccion;
        this.telefono = b.telefono;
        this.fechaNacimiento = b.fechaNacimiento;
    }

    public String getNombre() { return nombre; }
    public String getEmail() { return email; }
    public String getDireccion() { return direccion; }
    public String getTelefono() { return telefono; }
    public LocalDate getFechaNacimiento() { return fechaNacimiento; }

    @Override
    public Usuario clone() {
        // Strings and LocalDate are immutable - shallow copy is safe
        return new Builder()
                .setNombre(this.nombre)
                .setEmail(this.email)
                .setDireccion(this.direccion)
                .setTelefono(this.telefono)
                .setFechaNacimiento(this.fechaNacimiento)
                .build();
    }

    @Override
    public String toString() {
        return "Usuario{nombre='" + nombre + "', email='" + email + "', direccion='" + direccion + "', telefono='" + telefono + "', fechaNacimiento=" + fechaNacimiento + "}";
    }

    public static class Builder {
        private String nombre;
        private String email;
        private String direccion;
        private String telefono;
        private LocalDate fechaNacimiento;

        public Builder setNombre(String nombre) { this.nombre = nombre; return this; }
        public Builder setEmail(String email) { this.email = email; return this; }
        public Builder setDireccion(String direccion) { this.direccion = direccion; return this; }
        public Builder setTelefono(String telefono) { this.telefono = telefono; return this; }
        public Builder setFechaNacimiento(LocalDate fecha) { this.fechaNacimiento = fecha; return this; }

        public Usuario build() {
            return new Usuario(this);
        }
    }
}
