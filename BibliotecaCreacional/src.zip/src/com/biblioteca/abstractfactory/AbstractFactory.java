package com.biblioteca.abstractfactory;

public interface AbstractFactory {
    void mostrarPantalla();
}
