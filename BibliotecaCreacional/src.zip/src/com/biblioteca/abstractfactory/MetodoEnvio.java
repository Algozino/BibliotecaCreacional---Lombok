package com.biblioteca.abstractfactory;

public interface MetodoEnvio {
    void enviar(String detalle);
}
